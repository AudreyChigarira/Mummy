﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$("#file-upload").css("opacity", "0");

$("#file-browser").click(function (e) {
    e.preventDefault();
    $("#file-upload").trigger("click");
});
